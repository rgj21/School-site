

let getBody = document.querySelector(".message");

let newElement = document.createElement("h1");

let date = new Date();

let currentHour = date.getHours();

  console.log(currentHour);

let createTxtMsg;


if(currentHour >= 4 && currentHour < 10){
  createTxtMsg = " Goedemorgen, wat wilt u doen?";
}else if (currentHour >= 10 && currentHour < 12) {
    createTxtMsg = "Goedemorgen, wat wilt u doen?";
}else if (currentHour >= 12 && currentHour < 18) {
    createTxtMsg = "Goedemiddag, wat wilt u doen?";
}else if (currentHour >= 18 && currentHour < 22) {
    createTxtMsg = "Goedeavond, wat wilt u doen?";
}else if((currentHour >= 22 && currentHour < 24) || (currentHour >= 0 && currentHour < 4) ){
    createTxtMsg = "Goedenacht, wat wilt u doen?";
}
﻿else {

  createTxtMsg = "rare tijd :(";

}


let createEleText = document.createTextNode(createTxtMsg);

newElement.appendChild(createEleText);

getBody.appendChild(newElement);

newElement.setAttribute("class","login-status");


 // newElement.style.cssText = "text-align: center;, font-size 26px; font-family: arial; color: #111;";
