<?php
//require_once 'session.inc.php';
require_once 'config.php';
?>
<?php

$id = $_GET['ID'];

if (is_numeric($id)){
	$result = mysqli_query($mysqli,"SELECT * FROM Reserveringen WHERE ID = $id");

	if (mysqli_num_rows($result) == 1 ){
		$row = mysqli_fetch_array($result);
	}else{
		echo "geen lid gevonden";
		exit;
	}

}else{
	echo "onjuist ID";
	exit;
}
?><html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>	aanpassen | Kakischool</title>
	
	<link rel="shortcut icon" type="image/png" href="img/edit.png"/>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />
	

	
<!--
	<link rel="stylesheet" type="text/css" href="jquery.datetimepicker.min.css">
	
	<script src="jquery.js"></script>
	<script src="jquery.datetimepicker.full.js"></script>
-->

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>
	<div id="booking" class="section">
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-md-push-5">
						<div class="booking-cta">
							<h1>Welkom en reserveer!</h1>
							<p>Reserveer hier u datum en tijd voor de ouderavond
							</p>
						</div>
					</div>
					<div class="col-md-4 col-md-pull-8">
						<div class="booking-form"><?php
							//error meldingen
								if (isset($_GET["error"])) {
										if ($_GET["error"] == "emptyfields") {
											echo '<p class="red">Vul alle velden in!</p>';
            							}
									
										else if ($_GET["error"] == "usertaken") {
              							echo '<p class="red">Tijdstip al in gebruik!</p>';
            									}
									
									else if ($_GET["error"] == "invaliduid") {
              							echo '<p class="red">Onjuiste combinatie van tekens bij uw voornaam!</p>';
            									}
									
									else if ($_GET["error"] == "invaliduidA") {
              							echo '<p class="red">Onjuiste combinatie van tekens bij uw achternaam!</p>';
            									}
									
									else if ($_GET["error"] == "invalidmail") {
              							echo '<p class="red">Vul aub een juiste mail combinatie in!</p>';
            									}
									
								}
							          else if (isset($_GET["signup"])) {
										  	if ($_GET["signup"] == "success") {
													echo '<p class="signupsuccess">afspraak maken gelukt!</p>';
												}
          									}
									?>
							<form action="wijzigen_verwerk.php" method="post">
								<div class="form-group">
									
									<input type="hidden" name="ID" id="ID" value="<?php	echo $row['ID'];?>"> 
									<span class="form-label">Voornaam:*</span>
									<input class="form-control" type="text" name="Voornaam" id="Voornaam" placeholder="Voornaam..." required value="<?php	echo $row['Voornaam'];?>">
								</div>
								
								<div class="form-group">
									<span class="form-label">Achternaam:*</span>
									<input class="form-control" type="text" name="Achternaam" id="Achternaam" placeholder="Achternaam..." required value="<?php	echo $row['Achternaam'];?>">
								</div>
								
								<div class="form-group">
									<span class="form-label">Ouders/verzorgers van:*</span>
									<input class="form-control" type="text" name="Verzorgers" id="Verzorgers" placeholder="Naam van zoon/dochter..." required value="<?php	echo $row['Verzorgers'];?>" >
								</div>
								<div class="form-group">
									<span class="form-label">e-mail*</span>
									<input class="form-control" type="email" name="Email" id="Email" placeholder="Uw e-mailadres..." required value="<?php	echo $row['Email'];?>">
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<span class="form-label">Kies je datum en tijdstip*</span>

											<select selected class="form-control" name="Tijdstip" >
												<option   value="">--Selecteer een tijd--</option>
													<?php
											require 'loginsystem/includes/dbh.inc.php';

											$query = "SELECT * FROM Tijden";

											$result = mysqli_query($conn,$query);

											while ($datums = mysqli_fetch_array($result)){
												echo "<option value ='" . $datums['Tijdstip'] ."'>";
												echo $datums['Tijdstip'];
												echo "</option>";
											}



											?>
										</select>
											<span class="select-arrow"></span>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-11">
										<div class="form-group">
											<span class="form-label">Hoeveel personen zijn aanwezig?*</span>
											<select name="Personen" id="Personen" class="form-control">
												<option disabled value="<?php echo $row['Personen'];?>">max 4 personen</option>
												<option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
												<option value="4">4</option>
											</select>
											<span class="select-arrow"></span>
										</div>
									</div>
					
								</div>
								
								<div class="form-group">
									<span class="form-label">Opmerkingen:</span>
								<textarea name="Opmerkingen" id="Opmerkingen" cols="30" rows="10" placeholder="Plaats hier u opmerkingen als u die heeft...."><?php echo $row['Opmerkingen'];?></textarea>
								</div>
								
								<div class="form-btn">
									<button name="submit" class="submit-btn">Opslaan</button> &nbsp;&nbsp;
									<button class="btn-warning" onclick="goBack()">Terug</button>
								</div><br>
							<p class="black">  * is verplicht</p>
							</form>
						
					</div>
				</div>
			</div>
		</div>
			</div>
	</div>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

<script>
function goBack() {
    window.history.back();
}
</script>

</html>