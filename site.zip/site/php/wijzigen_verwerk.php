	<?php
error_reporting(E_ALL);
ini_set('display_errors','1');

require_once ('config.php');
$id = $_POST['ID'];
$Voornaam = $_POST['Voornaam'];
$Achternaam = $_POST['Achternaam'];
$Email = $_POST['Email'];
$Tijdstip = $_POST['Tijdstip'];
$Personen = $_POST['Personen'];
$Opmerkingen = $_POST['Opmerkingen'];
$Verzorgers = $_POST['Verzorgers'];

if (is_numeric($id) &&
 	strlen($id)			> 0 &&
	strlen($Voornaam) > 0 &&
	strlen($Achternaam) > 0 &&
	strlen($Email) > 0 &&
	strlen($Tijdstip) > 0 &&
	strlen($Personen) > 0 &&
	strlen($Opmerkingen) > 0 &&
	strlen($Verzorgers) > 0){
	
	
	
	 // We also need to include another error handler here that checks whether or the username is already taken. We HAVE to do this using prepared statements because it is safer!

    // First we create the statement that searches our database table to check for any identical usernames.
   // $sql = "SELECT Tijdstip FROM Reserveringen WHERE Tijdstip=?;";
	  $sql = "SELECT  Tijdstip FROM Reserveringen WHERE Tijdstip=?; ";
    // We create a prepared statement.
    $stmt = mysqli_stmt_init($mysqli);
    // Then we prepare our SQL statement AND check if there are any errors with it.
    if (!mysqli_stmt_prepare($stmt, $sql)) {
      // If there is an error we send the user back to the signup page.
      header("Location: wijzigen.php?error=sqlerror1");
      exit();
    }
    else {
      // Next we need to bind the type of parameters we expect to pass into the statement, and bind the data from the user.
      // In case you need to know, "s" means "string", "i" means "integer", "b" means "blob", "d" means "double".
      mysqli_stmt_bind_param($stmt, "s", $Tijdstip);
      // Then we execute the prepared statement and send it to the database!
      mysqli_stmt_execute($stmt);
      // Then we store the result from the statement.
      mysqli_stmt_store_result($stmt);
      // Then we get the number of result we received from our statement. This tells us whether the username already exists or not!
      $resultCount = mysqli_stmt_num_rows($stmt);
      // Then we close the prepared statement!
      mysqli_stmt_close($stmt);
      // Here we check if the username exists.
      if ($resultCount > 0) {
        header("Location: wijzigen.php?error=usertaken&ID=".$id);
        exit();
	  }

//		$result = mysqli_query($mysqli,"SELECT Tijdstip FROM Reserveringen WHERE Tijdstip = $Tijdstip");
//		$num_rows = mysqli_num_rows($result);
//	echo $num_rows;
//	die;
//	if ($num_rows > 0) {
//        header("Location: wijzigen.php?error=usertaken&ID=".$id);
//        exit();
//      }
//		

	$query = "UPDATE  Reserveringen SET Voornaam = '$Voornaam', Achternaam ='$Achternaam', Email = '$Email', Tijdstip ='$Tijdstip', Personen ='$Personen', Opmerkingen ='$Opmerkingen',
	Verzorgers ='$Verzorgers' WHERE ID = $id";
	
		$result = mysqli_query($mysqli,$query);

		if ($result){
			header ("Location:uitlees.php");
			exit;
		}
	else{
		echo  header("Location: wijzigen.php?error=emptyfields&ID=".$id);
        exit();
		}
	}
}











?>
