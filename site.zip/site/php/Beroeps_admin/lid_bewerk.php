
<!DOCTYPE html>
<html lang="NL">
		
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | SchoolSite </title>
	  <link rel="stylesheet" href="style.css">
<!--   Hier pak ik de bootstrap-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--    Hier style ik de bootstrap-->
    <link href="css/scrolling-nav.css" rel="stylesheet">
	  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	  <style type="text/css">
textarea.html-text-box {
background-color:ffffff;
background-repeat:no-repeat;
background-attachment:fixed;
border-width:1;
border-style:solid;
border-color: #23FF5F;;
font-family:Arial;
font-size:8pt;
color:000000;
width: 80%;
height: 300px;
	}
input.html-text-box{
background-color:ffffff;
font-family:Arial;
font-size:8pt;
color:000000;
padding-left: 30px;
		 }

</style>

  </head>

  <body id="page-top">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
      <div class="container">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="https://82261.ict-lab.nl/Beroeps/">Home</a>
            </li>
          
          </ul>
        </div>
      </div>
   		 </nav>
   		 <header class="bg-primary text-white">
    	  <div class="container text-center">
        <h1>Wijzig pagina</h1>
     	 </div>
    	</header>
    	
			  
			  	<?php 
	require "dbConfig.php";
	$id = $_GET['id'];
	
	if(is_numeric($id))	{
	$result = mysqli_query($mysqli, "SELECT * FROM home WHERE id= $id");
	}
	
	if (mysqli_num_rows($result) == 1)
	{		
	$row = mysqli_fetch_array($result);
	}
	
	else{
	echo "Geen lid gevonden.";
	exit;
	}
	?>
			  <br><br>
        </div>
      </div>
    </section>
	  <form method="post" action="lid_bewerk_verwerk.php">
	<p> 
<input type="hidden" name="id" id="first_name" value="<?php echo $row['id'] ?>">
	</p>
<textarea name="Tekstvak" id="Tekstvak" style="margin-left: 150px" class="html-text-box"><?php echo $row['Tekstvak']; ?></textarea>

<p><input type="submit" value="Verstuur" class="html-text-box">
	<input type="reset" value="Reset" class="html-text-box"></p>
	<button onclick="history.back();return false;">Annuleren</button>
</form>
<!--    Footer van de site-->
    <footer class="py-5 bg-dark" id="Footer">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Vishaal Sanichar, Yassine Tourich, Renato Gomes en Robel Keflezghi</p>
      </div>
    </footer>
  
  </body>
</html>
