<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Lon</title>
	<link rel="stylesheet" href="style.css">
	<style>
		
		
		.dag1{
			border: 5px solid black;
			padding: 20px;
			margin: 1px;
			}
		.dag2{
			
		}
	
	</style>
</head>
<body>
	
</body>
</html>

<?php
//Pak de API
$url = "api.openweathermap.org/data/2.5/weather?q=Rotterdam,nl&APPID=c6eee7cb7e6c5bc973db25dd7d45c656";
$url2 = "api.openweathermap.org/data/2.5/forecast?q=Rotterdam,nl&APPID=c6eee7cb7e6c5bc973db25dd7d45c656";


// url handler
	$ch = curl_init();
		//don't include the header
		curl_setopt($ch,CURLOPT_URL, $url);
		//return transfer as string
		curl_setopt($ch,CURLOPT_HEADER, 0);
		//voer de cURL opdracht uit
		curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
	//Toon de dat op de scherm
	$data = curl_exec($ch);

  curl_close($ch);
// De data naar JSON overzetten
$nieuw = json_decode($data);

$lengte = $nieuw->coord->lon;
$temp = $nieuw->main->temp - 273.15;
$naam = $nieuw->name;
$lengte = $nieuw->coord->lat;
$land = $nieuw->sys->country;
$wind = $nieuw->wind->speed * 3.6;
$windrichting = $nieuw->wind->deg;
$zonsopgang = $nieuw->sys->sunrise;
$zonsondergang = $nieuw->sys-sunset;
$icon = "http://openweathermap.org/img/w/".$nieuw->weather[0]->icon;


echo "Lengtegraad = ". $lengte . "<br/>";

echo "temperatuur = " . $temp . "&deg; C <br/>";

echo "de naam is = " . $naam . "<br/>";

echo "Breedtegraad = ". $lengte . "<br/>";

echo "Naam van de land is = ". $land . "<br/>";

echo "De windkracht is = ". $wind . "KM/u" . "<br/>";

echo "De windrichting is = ". $windrichting . "&deg; <br/>";

echo "De zonsopgang is om = " . date('h:i:s',$zonsopgang) . "<br/>";

echo "De zonondergang is om = " . date('h:i:s',$zonsondergang) . "<br/>";




?>
<img src="<?php echo $icon;?>.png" alt="">




<?php







	 

//
////
//echo "<pre>";
//print_r($nieuw);
//echo "</pre>";
//
//
////
//echo "<pre>";
//print_r($nieuw2);
//echo "</pre>";





//--------------Forecast----------------------------


// url handler
	$ah = curl_init();
		//don't include the header
		curl_setopt($ah,CURLOPT_URL, $url2);
		//return transfer as string
		curl_setopt($ah,CURLOPT_HEADER, 0);
		//voer de cURL opdracht uit
		curl_setopt($ah,CURLOPT_RETURNTRANSFER, 1);
	//Toon de dat op de scherm
	$data2 = curl_exec($ah);

  curl_close($ah);
// De data naar JSON overzetten
$nieuw2 = json_decode($data2);

$icon2 = "http://openweathermap.org/img/w/".$nieuw2->list[8]->weather[0]->icon;
$icon3 = "http://openweathermap.org/img/w/".$nieuw2->list[16]->weather[0]->icon;
$icon4 = "http://openweathermap.org/img/w/".$nieuw2->list[24]->weather[0]->icon;


//--------------------------------Dag 1 ----------------------
?>
<?php
echo '<div class="dag1">';

$dag1 = $nieuw2 ->list[8]->dt_txt;
echo " Morgen is de " . $dag1. "<br>";

$temp2 = $nieuw2 ->list[8]->main->temp;
echo "de temperatuur van deze dag is =" .$temp2. "<br>";

$luchtdruk = $nieuw2 ->list[8]->main->pressure;
echo " luchtdruk = " .$luchtdruk. "&deg; C <br>";

$weerbeschrijving1 = $nieuw2->list[8]->weather[0]->description;



?>
<img src="<?php echo $icon2;?>.png">

<?php									
echo '</div>';
//--------------------------------Dag 2 ----------------------

echo '<div class="dag1">';


$dag2 = $nieuw2 ->list[16]->dt_txt;
echo "<div class ='dag2'> Morgen is de " . $dag2. "</div>";

$temp3 = $nieuw2 ->list[16]->main->temp;
echo "de temperatuur van deze dag is =" .$temp3. "<br>";

$luchtdruk1 = $nieuw2 ->list[16]->main->pressure;
echo " luchtdruk = " .$luchtdruk1. "&deg; C <br>";

$weerbeschrijving2 = $nieuw2->list[16]->weather[0]->description;

echo " Het word ".$weerbeschrijving2. "</div>";
									

?>
<img src="<?php echo $icon3;?>.png">

					

<?php

echo '</div>';

//--------------------------------Dag 3 ----------------------

echo '<div class="dag1">';


$dag3 = $nieuw2 ->list[24]->dt_txt;
echo "<div class ='dag2'> Morgen is de " . $dag3. "</div>";

$temp4 = $nieuw2 ->list[24]->main->temp;
echo "de temperatuur van deze dag is =" .$temp4. "<br>";

$luchtdruk2 = $nieuw2 ->list[24]->main->pressure;
echo " luchtdruk = " .$luchtdruk2. "&deg; C <br>";

$weerbeschrijving3 = $nieuw2->list[24]->weather[0]->description;


?>
<img src="<?php echo $icon4;?>.png">

<?php
echo '</div>';

//echo "<pre>";
//print_r($nieuw2);
//echo "</pre>";
?>