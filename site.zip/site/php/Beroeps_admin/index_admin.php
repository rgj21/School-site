<!--
<?php
//session_start();
//if (!isset($_SESSION['id'])) {
//	header("Location: https://82132.ict-lab.nl/Beroeps/P2/site/php/loginsystem/login_docenten.php");
//	
//}
?>
-->
<!DOCTYPE html>
<html lang="NL">
		
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | SchoolSite </title>
	  <link rel="stylesheet" href="style.css" type="text/css">
<!--   Hier pak ik de bootstrap-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--    Hier style ik de bootstrap-->
    <link href="css/scrolling-nav.css" type="text/css" rel="stylesheet">
	  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	  

  </head>

  <body id="page-top">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
      <div class="container">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="https://82261.ict-lab.nl/Beroeps/index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="https://82132.ict-lab.nl/Beroeps/P2/site/php/loginsystem/index.html">Inlog</a>
            </li>
          </ul>
        </div>
      </div>
   		 </nav>
   		 <header class="bg-primary text-white" id="Kind">
    	  <div class="container text-center">
        <h1>Welkom op onze schoolsite</h1>
        <p class="lead">Vind hier de informatie over de opkomende ouderavond!</p>
     	 </div>
    	</header>
    	<section id="about">
      	<div class="container">
        <div class="row">
          <div class="col-lg-8 mx-auto">
			  
			  	<?php
	//Verbinden met Database
	require 'dbConfig.php';
	//Maak opdracht
	$query = "SELECT * FROM home ";
	
	//Voer opdracht uit
	//Zet het resultaat in een variabele
	$result = mysqli_query($mysqli, $query);
	


	while ($row = mysqli_fetch_array($result)){
	
		//Maak cellen voor gegevens
		
		
		
		 echo  "<a class='poep' href='lid_bewerk.php?id=" . $row['id'] . "'>Wijzigen</a>";
		echo "<br><br><br>";
		echo "<div class='kind'>";
		echo "<td>" . $row['Tekstvak'] . "</td></br>";
		echo "</div>";
		
	
	}
	
	?>
			  <br><br>
			  <img src="img/foto.png" alt="Kinderen" class="img-fluid" id="iedereen">
          </div>
        </div>
      </div>
			 <footer class="py-5 bg-dark" id="Footer">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Vishaal</p>
      </div>
    </footer>
    </section>
	  
<!--    Footer van de site-->
   
  
  </body>
</html>
