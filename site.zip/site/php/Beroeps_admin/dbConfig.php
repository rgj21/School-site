<?php
// Database configuration
error_reporting(E_ALL);
ini_set('display_errors','1');
$dbHost     = "localhost";
$dbUsername = "reservering";
$dbPassword = "geheim1!";
$dbName     = "Reserveringsite";

// Create database connection
$mysqli = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $db->connect_error);
	echo "Kan niet verbinden met de database. <br>";
}
?>