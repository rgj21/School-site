<!doctype html>
<html>
<head>
	
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>

<body>
	<?php
	//Verbinden met Database
	require 'dbConfig.php';
	//Maak opdracht
	$query = "SELECT * FROM home ";
	
	//Voer opdracht uit
	//Zet het resultaat in een variabele
	$result = mysqli_query($mysqli, $query);
	


	while ($row = mysqli_fetch_array($result)){
		
		
		
		//Maak cellen voor gegevens
		
		echo "<td>" . $row['Tekstvak'] . "</td></br>";
		echo "</br><td><a href='lid_bewerk.php?id=" . $row['id'] . "'>bewerk</a></td>";

	}
	
	?>
</body>
</html>