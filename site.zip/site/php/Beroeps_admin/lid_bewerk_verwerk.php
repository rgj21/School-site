<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>

<body>
	<?php 
	require "dbConfig.php";
	
 	//Lees alle velden uit
	$id	= $_POST['id'];
	$Tekstvak	= $_POST['Tekstvak'];
	//Controlleer of het is ingevuld
	

	
	//Controleer of correct is
	
	
	
    $query = "UPDATE home
		SET
		Tekstvak = '$Tekstvak'
		WHERE id = $id";
	   
	  $result= mysqli_query($mysqli, $query);
	
	if($result){
		header("Location:index_admin.php");
		exit;
	}
	else{
		var_dump($result);
		echo 'Error a niffauw!';
	}

	?>

	
</body>
</html>