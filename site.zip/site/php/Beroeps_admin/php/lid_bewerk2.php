<!doctype html>
<html>
<head>
	<style type="text/css">
textarea.html-text-box {background-color:ffffff;background-repeat:no-repeat;background-attachment:fixed;border-width:1;border-style:solid;border-color:cccccc;font-family:Arial;font-size:8pt;color:000000;}
input.html-text-box {background-color:ffffff;font-family:Arial;font-size:8pt;color:000000;}
</style>
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>
<body>
<?php 
	require "dbConfig.php";
	$id = $_GET['id'];
	
	if(is_numeric($id))	{
	$result = mysqli_query($mysqli, "SELECT * FROM home WHERE id= $id");
	}
	
	if (mysqli_num_rows($result) == 1)
	{		
	$row = mysqli_fetch_array($result);
	}
	
	else{
	echo "Geen lid gevonden.";
	exit;
	}
	?>

<form method="post" action="lid_bewerk_verwerk.php">
	<p> 
<input type="hidden" name="id" id="first_name" value="<?php echo $row['id'] ?>">
	</p>
<textarea name="Tekstvak" id="Tekstvak" cols="50" rows="10" class="html-text-box"><?php echo $row['Tekstvak']; ?></textarea>

<p><input type="submit" value="Verstuur" class="html-text-box"><input type="reset" value="Reset" class="html-text-box"></p>
	<button onclick="history.back();return false;">Annuleren</button>
</form>
</body>
</body>
</html>