<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
<link rel="stylesheet" href="style2.css">
</head>
<body>
	
</body>
</html>
<?php
// Api keys + API site
$datum = new DateTime('tomorrow');

$url = "http://api.filmtotaal.nl/filmsoptv.xml?";
$url .= "apikey=er9h4unoeyncpple3jterq4bcf5uj7nq";
$url .= "&dag=".$datum->format('d-m-Y')."&sorteer=0";
// url handler
	$ch = curl_init();
		//don't include the header
		curl_setopt($ch,CURLOPT_URL, $url);
		//return transfer as string
		curl_setopt($ch,CURLOPT_HEADER, 0);
		//voer de cURL opdracht uit
		curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
	//Toon de dat op de scherm
	$data = curl_exec($ch);

  curl_close($ch);
// De data naar JSON overzetten
$nieuw = new SimpleXMLElement($data); 
//
//echo "<pre>";
//	print_r($nieuw);
//echo "</pre>";



//echo $titel;
foreach($nieuw->film as $film)

{
	$titel= $nieuw->film[0]->titel;

	$timestamp  		= (string)  $film->starttijd;
	$jaar 				= (string)	$film->jaar;	
	$genre 				= (string)	$film->genre;	
	$land 				= (string)	$film->land;	
	$ft_rating 			=			$film->ft_rating;	
	$synopsis 			= (string)	$film->synopsis;	
	$cast 				= (string)	$film->cast;
	$ft_votes			=			$film->ft_votes;
	$imdb_rating		= (string)	$film->imdb_rating;
	$imdb_id			= (string)	$film->imdb_id;
	$eindtijd  			= (string)  $film->eindtijd;
	$duur				= (string)	$film->duur;
	$regisseur			= (string)	$film->regisseur;
	$zender				= (string)	$film->zender;
	$ft_link			= 			$film->ft_link;
	
	
	$colon	=	[":", ";"];
	$genre	=	str_replace($colon, ",", $genre);
	$cast	=	str_replace($colon, ",", $cast);

	
	echo "<div class='Film'>";
	echo "Titel: " . $titel . "</br></br>";
	echo "Jaar uitgekomen: " . $jaar . "</br></br>";
	echo "Genre:  " . $genre . "</br></br>";
	echo "Land van herkomst:" . $land . "</br></br>";
	echo "Rating : " . $ft_rating . "</br></br>";
    echo "Starttijd: " . gmdate("H:i", $timestamp) . "</br></br>";
	echo "Beschrijving: ". $synopsis . "</br></br>";
	echo "De acteurs van de film:". $cast . "</br></br>";
	echo "De tagline van deze film ". $tagline . "</br></br>";
	echo "Stemmen van FT: " . $ft_votes . "</br></br>";
	echo "ID nummer : " . $imdb_id . "<br/></br>";
	echo "Rating van IMDB : " . $imdb_rating . "<br/></br>";
	echo "EindTijd: " . gmdate("H:i", $eindtijd) . "<br/></br>";
	echo "Duur van de film: " . $duur . "min" . "<br/></br>";
	echo "De regisseur van de film : " . $regisseur .  "<br/></br>";
	echo "Deze film word uitgezonden op kanaal : " . $zender . "<br/></br>";
	echo "<a href='$ft_link'>Bezoek de site</a><br/></br>";
	echo "</div>";
	
	
	
	
	
	?>
	<img class="Film" src="<?php echo $film->cover . "";?>"/></br>
<?php
}