<?php
//Pak de API
$url = "api.openweathermap.org/data/2.5/forecast?q=Rotterdam,nl&APPID=c6eee7cb7e6c5bc973db25dd7d45c656";


// url handler
	$ch = curl_init();
		//don't include the header
		curl_setopt($ch,CURLOPT_URL, $url);
		//return transfer as string
		curl_setopt($ch,CURLOPT_HEADER, 0);
		//voer de cURL opdracht uit
		curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
	//Toon de dat op de scherm
	$data = curl_exec($ch);

  curl_close($ch);
// De data naar JSON overzetten
$nieuw = json_decode($data);

$lengte = $nieuw->coord->lon;
$temp = $nieuw->temp - 273.15;
$naam = $nieuw->city->name;
$lengte = $nieuw->city->coord->lat;
$land = $nieuw->city->country;
$wind = $nieuw->wind->speed * 3.6;
$windrichting = $nieuw->wind->deg;
$zonsopgang = $nieuw->sys->sunrise;
$zonsondergang = $nieuw->sys-sunset;
$icon = $nieuw->weather->icon;


echo "Lengtegraad = ". $lengte . "<br/>";

echo "temperatuur = " . $temp . "&deg; C <br/>";

echo "de naam is = " . $naam . "<br/>";

echo "Breedtegraad = ". $lengte . "<br/>";

echo "Naam van de land is = ". $land . "<br/>";

echo "De windkracht is = ". $wind . "KM/u" . "<br/>";

echo "De windrichting is = ". $windrichting . "&deg; <br/>";

echo "De zonsopgang is om = " . date('h:i:s',$zonsopgang) . "<br/>";

echo "De zonondergang is om = " . date('h:i:s',$zonsondergang) . "<br/>";

echo "De icon is = " . $icon .  "<br/>";






echo "<pre>";
print_r($nieuw);
echo "</pre>";
