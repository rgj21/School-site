<?php
session_start();

require 'config.php';

$id = $_SESSION['id'];

if (!isset($_SESSION['id'])){
	header("Location:https://82132.ict-lab.nl/Beroeps/P2/site/php/loginsystem/login_ouders.php?error=inval");

}


?>


<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>School l Reserveren</title>
	<link rel="shortcut icon" type="image/png" href="img/reserveer.png"/>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<script src="https://code.jquery.com/jquery-3.3.1.min.js"
	integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
	crossorigin="anonymous"></script>


<!--
	<link rel="stylesheet" type="text/css" href="jquery.datetimepicker.min.css">

	<script src="jquery.js"></script>
	<script src="jquery.datetimepicker.full.js"></script>
-->

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>
<script type="text/javascript" >
setTimeout(function(){
	document.getElementById('info-message').style.display = 'none';
$('#info-message').fadeIn('slow').delay(3000).fadeOut('slow');
});

</script>

<body>
	<div id="booking" class="section">
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-md-push-5">
						<div class="booking-cta">
							<h1>Welkom en reserveer!</h1>
							<p>Reserveer hier u datum en tijd voor de ouderavond
							</p>
						</div>
					</div>
					<div class="col-md-4 col-md-pull-8">
						<div class="booking-form"><?php
							//error meldingen
								if (isset($_GET["error"])) {
										if ($_GET["error"] == "emptyfields") {
											echo '<p class="red">Vul alle velden in!</p>';
            							}

										else if ($_GET["error"] == "usertaken") {
              							echo '<p class="red">Tijdstip al in gebruik!</p>';
            									}

									else if ($_GET["error"] == "invaliduid") {
              							echo '<p class="red">Onjuiste combinatie van tekens bij uw voornaam!</p>';
            									}

									else if ($_GET["error"] == "invaliduidA") {
              							echo '<p class="red">Onjuiste combinatie van tekens bij uw achternaam!</p>';
            									}

									else if ($_GET["error"] == "invalidmail") {
              							echo '<p class="red">Vul aub een juiste mail combinatie in!</p>';
            									}

								}
							          else if (isset($_GET["signup"])) {
										  	if ($_GET["signup"] == "success") {
													echo  '<p id="info-message">uw afspraak is toegevoegd</p>';

												}
          									}
									?>
							<form action="reserveren_test.php" method="post">
								<div class="form-group">
									<input type="hidden" name="id" value="<?php echo $_SESSION['id'];?>" >
									<input type="hidden" name="power" value="1" >
									<span class="form-label">Voornaam:*</span>
									<?php
									// We check username.
            						if (!empty($_GET["Voornaam"])) {
              							echo '<input class="form-control" type="text" name="Voornaam" placeholder="Voornaam..." value="'.$_GET["Voornaam"].'" >';
											}else {
												echo '<input class="form-control" type="text" name="Voornaam" value="'.$_SESSION["uid"].'" required>';
											}?>

								</div>

								<div class="form-group">
									<span class="form-label">Achternaam:*</span>
									<?php
									if (!empty($_GET["Achternaam"])) {
											echo '<input class="form-control" type="text" name="Achternaam" placeholder="Achternaam..." value="'.$_GET["Achternaam"].'" >';
								}else{
									echo '<input class="form-control" type="text" name="Achternaam" id="Achternaam" value="'.$_SESSION["last_name"].'" required>';
								}
									?>
								</div>

								<div class="form-group">
									<span class="form-label">Ouders/verzorgers van:*</span>
									<?php
									if (!empty($_GET["Verzorgers"])) {
											echo '<input class="form-control" type="text" name="Verzorgers" placeholder="Naam van zoon/dochter..." value="'.$_GET["Verzorgers"].'" >';
								}else {
										echo '<input class="form-control" type="text" name="Verzorgers" id="Verzorgers" placeholder="Naam van zoon/dochter...">';
								}
								?>
								</div>
								<div class="form-group">
									<span class="form-label">e-mail*</span>
									<?php
									// We check username.
            						if (!empty($_GET["mail"])) {
              							echo '<input class="form-control" type="mail" name="Email" id="Email" placeholder="Uw e-mailadres..." value="'.$_GET["mail"].'">';
											}else {
												echo '<input class="form-control" type="text" id="Email" name="Email" placeholder="Uw e-mail-adres..." required>';
											}?>

								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<span class="form-label">Kies je datum en tijdstip*</span>

											<select  class="form-control" name="Tijdstip" >
												<option  value="">--Selecteer een tijd--</option>
													<?php
											require 'loginsystem/includes/dbh.inc.php';

											$query = "SELECT * FROM Tijden";

											$result = mysqli_query($conn,$query);

											while ($datums = mysqli_fetch_array($result)){
												echo "<option value ='" . $datums['Tijdstip'] ."'>";
												echo $datums['Tijdstip'];
												echo "</option>";
											}



											?>
										</select>
											<span class="select-arrow"></span>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-11">
										<div class="form-group">
											<span class="form-label">Hoeveel personen zijn aanwezig?*</span>
											<select name="Personen" id="Personen" class="form-control">
												<option disabled>max 4 personen</option>
												<option>1</option>
												<option>2</option>
												<option>3</option>
												<option>4</option>
											</select>
											<span class="select-arrow"></span>
										</div>
									</div>

								</div>

								<div class="form-group">
									<span class="form-label">Opmerkingen:</span>
								<textarea name="Opmerkingen" id="Opmerkingen" cols="30" rows="10" placeholder="Plaats hier u opmerkingen als u die heeft...."></textarea>
								</div>

								<div class="form-btn">
									<button name="submit" class="submit-btn">Opslaan</button> &nbsp;&nbsp; <button onclick="goBack()" class="btn-warning">Terug</button>
								</div>
<!--
								<div class="form-btn">
								<button onclick="goBack()" class="submit-btn">Terug</button>
								</div>
-->
								<br>
							<p class="black">  * is verplicht</p>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</body>
<script>
function goBack() {
    window.history.back();
}
</script><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>
