<?php

//error_reporting(E_ALL);
//ini_set('display_errors','1');



//database connectie
require_once 'config.php';

$Voornaam = $_POST['Voornaam'];
$Achternaam = $_POST['Achternaam'];
$Email = $_POST['Email'];
$Datum = $_POST['Datum'];
$Tijdstip = $_POST['Tijdstip'];
$Personen = $_POST['Personen'];
$Opmerkingen = $_POST['Opmerkingen'];


if (strlen($Voornaam) > 0 &&
	strlen($Achternaam) > 0 &&
	strlen($Email) > 0 &&
	strlen($Datum) > 0 &&
	strlen($Tijdstip) > 0 &&
	strlen($Personen) > 0 &&
	strlen($Opmerkingen) > 0 ){


	$check1 = strtotime($Datum);


	if (date('Y-m-d',$check1)==$Datum){

		$query = "INSERT INTO Reserveringen (Voornaam,Achternaam,Email,Datum,Tijdstip,Personen,Opmerkingen)
    VALUES ('$Voornaam','$Achternaam','$Email','$Datum','$Tijdstip','$Personen','$Opmerkingen')";
		$result = mysqli_query($mysqli,$query);

		if ($result){
			header ("Location:uitlees.php");
			exit;
		}else{
			echo "er ging wat mis met toevoegen </br>";
			// echo $query . " </br>";
			// echo mysqli_error($mysqli);
		}
	}else{
		echo "niet alle velden waren ingevuld";
	}

}










?>
