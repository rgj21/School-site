<!--================================================================(Begin)PHP CODE================================================================-->
<?php
//	//User is ingelogd
	 session_start();

	//
	if(!isset($_SESSION['id'])){
	header("Location:https://82132.ict-lab.nl/Beroeps/P2/site/php/loginsystem/login_ouders.php?error=inval");
	}

?>
<!--================================================================(Einde)PHP CODE================================================================-->

<!--================================================================(Begin)HTML CODE================================================================-->
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Afspraken | Kakischool</title>
<link rel="shortcut icon" type="image/png" href="img/reader.png"/>

<link rel="stylesheet" type="text/css" href="css/style.css">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="../css/uitlees.css">
	<script src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>

	<script type="text/javascript" >
	setTimeout(function(){
		document.getElementById('info-message').style.display = 'none';
$('#info-message').fadeIn('slow').delay(3000).fadeOut('slow');
	});

	</script>
</head>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<!--
  <a class="navbar-brand" href="#">Home</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
-->



		<div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="https://82132.ict-lab.nl/Beroeps/P2/site/php/reserveren.php">Afspraak toevoegen<span class="sr-only">(current)</span></a>
      </li>




    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="https://82132.ict-lab.nl/Beroeps/P2/site/php/loginsystem/includes/logout.inc.php">Log uit<span class="sr-only">(current)</span></a>
      </li>
  </div>
</nav><br>

<body>
<?php
	if (isset($_GET["success"])) {
		if ($_GET["success"] == "edit") {
			echo '<p id="info-message">uw afspraak is aangepast</p>';
		}
	}
	?>
<!-- <span class="counter pull-right"></span> -->
<table class="table table-hover table-bordered results">
  <thead>
    <tr>



	  <th class="col-md-3 col-xs-8"><?php echo "Datum en tijdstip";?></th>
	  <th class="col-md-3 col-xs-7"><?php echo "Personen";?></th>
	  <th class="col-md-3 col-xs-8"><?php echo "Opmerkingen";?></th>
	  <th class="col-md-3 col-xs-8"><?php echo "Verzorgers";?></th>
	  <th class="col-md-3 col-xs-8"><?php echo "Actie";?></th>


    </tr>


    <tr class="warning no-result">
      <td colspan="4"><i class="fa fa-warning"></i> No result</td>

			<td colspan="4"><i class="fa fa-warning"></i> No result</td>
 </tr>
</thead>


<!--================================================================(Begin)PHP CODE================================================================-->
	<?php

	// Config pakken
	require ('config.php');


	// Maak de variable aan voor de rows
		$ID = $_SESSION['id'];
		$naam = $_SESSION['uid'];
		$mail = $_SESSION['email'];
		$achternaam = $_SESSION['last_name'];





		echo "<h1>Afspraken van : Dhr/Mvr $naam&nbsp;$achternaam  </h1>";


		// Maak de Query
		$query = "SELECT * FROM `Reserveringen` WHERE `idUsers` = $ID";


				//Vang het resultaat van de query op in 'resultaat'
				$resultaat = mysqli_query($mysqli, $query);


				// Als er geen resultaten binnenkomen
				if (mysqli_num_rows($resultaat) == 0)

				echo"<p> Er zijn geen resultaten gevonden </p>";
				// Als er wel rijen zijn gevonden
				else
				{

				//Maak een while loop om de resulaten te echo'e.
				while($row = mysqli_fetch_array($resultaat))
				{

				echo "<tr>";
				echo "<td>" . $row['Tijdstip']. "</td>";
				echo "<td>" . $row['Personen']. "</td>";
				echo "<td>" . $row['Opmerkingen']. "</td>";
				 echo "<td>" . $row['Verzorgers']. "</td>";
				echo "<td>" ."<a href='ouder_wijzgtest.php?ID=".$row['ID']."'> pas aan</a>". "</td>";


				//Suit de tabel af
				echo "</tr>";

			}




		}


	?>
	</table>

<!--================================================================(Einde)PHP CODE================================================================-->

<div class="form-btn">
<input type="button"  class="btn-danger" value="LOG UIT" onclick="window.location.href='https://82132.ict-lab.nl/Beroeps/P2/site/php/loginsystem/includes/logout.inc.php'"> &nbsp;&nbsp;
<input type="button"  class="btn-warning" value="Terug" onclick=window.location.href="https://82132.ict-lab.nl/Beroeps/P2/site/php/loginsystem/login_ouders.php?login=success">
</div>

</body>
</html>
<!--================================================================(Einde)HTML CODE================================================================-->
