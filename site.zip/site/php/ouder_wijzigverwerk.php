	<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors','1');

require_once ('config.php');


$id = $_SESSION['id'];
$Tijdstip = $_POST['Tijdstip'];
$Personen = $_POST['Personen'];
$Opmerkingen = $_POST['Opmerkingen'];
$Verzorgers = $_POST['Verzorgers'];

if (is_numeric($id) &&
 	strlen($id)			> 0 &&
	strlen($Tijdstip) > 0 &&
	strlen($Personen) > 0 &&
	strlen($Opmerkingen) > 0 &&
	strlen($Verzorgers) > 0){


	$query = "UPDATE  Reserveringen SET  Tijdstip ='$Tijdstip', Personen ='$Personen', Opmerkingen ='$Opmerkingen',
	Verzorgers ='$Verzorgers' WHERE ID = $id";
	
		$result = mysqli_query($mysqli,$query);

		if ($result){
			header ("Location:uitlees.php");
			exit;
		}else{
			echo "er ging wat mis met toevoegen </br>";
			echo $query . " </br>";
			echo mysqli_error($mysqli);
		}
	}
	else{
		echo "niet alle velden waren ingevuld";
	}












?>
