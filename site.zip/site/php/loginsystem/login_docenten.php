<?php

  session_start();

  require "includes/dbh.inc.php";
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="description" content="This is an example of a meta description. This will often show up in search results.">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <title>Login-Docenten | kakischool</title>
    <link rel="shortcut icon" type="image/png" href="../img/teacher.png"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link
  </head>
  <body>
    <main>
      <div class="wrapper-main">
        <section class="section-default">
          <!--
          We can choose whether or not to show ANY content on our pages depending on if we are logged in or not.
          -->
          <?php
			//error message voor lege velden
			if (isset($_GET["error"])) {
            if ($_GET["error"] == "emptyfields") {
              echo '<p class="signuperror">Vul alle velden!</p>';
            	}
				else if ($_GET["error"] == "wrongpwd") {
              echo '<p class="signuperror">Onjuiste wachtwoord!</p>';
            	}else if ($_GET["error"] == "wronguidpwd") {
              echo '<p class="signuperror">Onbekende gegevens!</p>';
            	}
			}


//          if ($_SESSION['power'] == 1) {
//          header("Location:https://82132.ict-lab.nl/Beroeps/P2/site/php/uitlees.php");
//
//         }
         echo "<h1>Login Docent</h1>";
          if (!isset($_SESSION['id'])) {
            echo '<form class="form-signup" action="includes/login.inc.php" method="post">
              <input type="text" name="mailuid" placeholder="Gebruikersnaam">
              <input type="password" name="pwd" placeholder="Wachtwoord">
              <button type="submit" class="btn-success" name="login-submit">Log in</button>
            </form>';
          }
          else if (isset($_SESSION['id'])) {
//            echo '<p class="login-status">You are logged in!</p>';
//        echo '<a href="https://82132.ict-lab.nl/Beroeps/P2/site/php/loginsystem/includes/logout_docenten.inc.php">index</a>';
           header("Location: https://82132.ict-lab.nl/Beroeps/P2/site/php/uitlees.php");
          }
 			// We check username.
            if (!empty($_GET["mailuid"])) {
              //echo '<input type="text" name="uid" placeholder="Gebruikersnaam" value="'.$_GET["mailuid"].'">';
            }
           
			
          ?>
        </section>
      </div>
    </main>
	  

<?php

  require "footer.php";
?>
