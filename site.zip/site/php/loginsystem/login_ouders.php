<?php

  session_start();
$voornaam = $_SESSION["uid"];
$achternaam = $_SESSION['last_name'];
  require "includes/dbh.inc.php";
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="description" content="This is an example of a meta description. This will often show up in search results.">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <title>ouders login | Kakischool</title>
    <link rel="shortcut icon" type="image/png" href="../img/Parents.ico"/>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <main>
      <div class="wrapper-main">
        <section class="section-default">
          <!--
          We can choose whether or not to show ANY content on our pages depending on if we are logged in or not.
          -->
          <?php
			//error message voor lege velden
			if (isset($_GET["error"])) {
            if ($_GET["error"] == "emptyfields") {
              echo '<p class="signuperror">Vul alle velden!</p>';
            	}
				else if ($_GET["error"] == "wrongpwd") {
              echo '<p class="signuperror">Onjuiste wachtwoord!</p>';
            	}else if ($_GET["error"] == "wronguidpwd") {
              echo '<p class="signuperror">Onbekende gegevens!</p>';
            	}

				else if ($_GET["error"] == "inval") {
              echo '<p class="signuperror">U moet ingelogd om deze pagina te bezoeken!</p>';
            	}
			}




			if (isset($_GET["succes"])== "inlog"){
				echo '<p class ="signupsuccess"> Account aangemaakt! Wilt u direct inloggen?</p><br>';
			}

          if (!isset($_SESSION['id'])) {
               echo "<h1>Login ouders</h1>";
            echo '<form class="form-signup" action="includes/login-users.inc.php" method="post">
              <input type="text" name="mailuid" placeholder="Gebruikersnaam">
              <input type="password" name="pwd" placeholder="Wachtwoord">
			  <button  class="btn-success" type="submit" name="login-submit">Log in</button> &nbsp;&nbsp;
			  





            </form>';
			  echo '<button class="btn-warning3" type="submit" onclick= "goBack()">Terug</button>';
			  			 //echo '<input type="button"  class="btn-warning3" value="Terug" onclick=window.location.href="https://82261.ict-lab.nl/Beroeps/index.php"><br><br>';




          }


          else if (isset($_SESSION['id'])) {

            // echo '<p class="login-status">Ingelogd als ouder!</p>';
             echo '<div class="message"></div><br><br>';
			echo '<input type="button"  class="btn-info" value="MAAK EEN AFSPRAAK" onclick=window.location.href="https://82132.ict-lab.nl/Beroeps/P2/site/php/reserveren.php"><br><br>';
			echo '<input type="button"  class="btn-danger2" value="LOG UIT" onclick=window.location.href="https://82132.ict-lab.nl/Beroeps/P2/site/php/loginsystem/includes/logout.inc.php"><br><br>';
			 	echo '<a href="../afspraak_uitlezen.php">Bekijk uw afspraken</a>';

          }

          ?>

        </section>

      </div>




    </main>
	
</body>
	<script>
function goBack() {
    window.history.back();
}
</script>


<script type="text/javascript" src="../../js/messag.js">

</script>
</html>
