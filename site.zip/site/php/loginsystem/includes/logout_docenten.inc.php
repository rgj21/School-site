<?php
session_start();
session_unset();
session_destroy();
header("Location:https://82132.ict-lab.nl/Beroeps/P2/site/php/loginsystem/login_docenten.php");
