<?php
// error_reporting(E_ALL);
// ini_set('display_errors','1');

$dBServername = "localhost";
$dBUsername = "reservering";
$dBPassword = "geheim1!";
$dBName = "Reserveringsite";

// Create connection
$conn = mysqli_connect($dBServername, $dBUsername, $dBPassword, $dBName);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
