<?php
session_start();
require "config.php";
if (!isset($_SESSION['id'])){
	header("Location:https://82132.ict-lab.nl/Beroeps/P2/site/php/loginsystem/login_docenten.php");
	
}

require_once 'config.php';
 

	$query = "SELECT * FROM Reserveringen";


	$result = mysqli_query($mysqli,$query);


?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Docenten-Registratie | Kakischool </title>
<link rel="shortcut icon" type="image/png" href="img/reader.png"/>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="../css/uitlees.css">
	<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
</head>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
		
		
		
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      
 


  
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="https://82132.ict-lab.nl/Beroeps/P2/site/php/loginsystem/includes/logout_docenten.inc.php">Log uit <span class="sr-only">(current)</span></a>
		  <a class="nav-link" href="https://82261.ict-lab.nl/Beroeps_admin/index_admin.php">Home<span class="sr-only">(current)</span></a>
      </li>
  </div>
</nav><br>

<body>
	
<h2>Ouderavond afspraken</h2>
	<div class="form-group pull-right">
    <input type="text" class="search form-control" placeholder="Zoek een afspraak op voornaam, achternaam, email, datum of tijd">
</div>

<!-- <span class="counter pull-right"></span> -->
<table class="table table-hover table-bordered results">
  <thead>
    <tr>


      <th class="col-md-4 col-xs-4"><?php echo " Voornaam ";?></th>
      <th class="col-md-3 col-xs-3"><?php echo " Achternaam ";?></th>
	  <th class="col-md-3 col-xs-2"><?php echo "Email";?></th>
	  <th class="col-md-3 col-xs-6"><?php echo "Datum en tijdstip";?></th>
	  <th class="col-md-3 col-xs-7"><?php echo "Personen";?></th>
	  <th class="col-md-3 col-xs-8"><?php echo "Opmerkingen";?></th>
	  <th class="col-md-3 col-xs-8"><?php echo "Actie";?></th>


    </tr>


    <tr class="warning no-result">
      <td colspan="4"><i class="fa fa-warning"></i> No result</td>

			<td colspan="4"><i class="fa fa-warning"></i> No result</td>
 </tr>
</thead>

		<?php


		while ($row = mysqli_fetch_array($result))
	{
		echo "<tr>";


		echo "<td>" . $row['Voornaam']."</td>";
		echo "<td>" . $row['Achternaam']."</td>";
		echo "<td>" . $row['Email']."</td>";
		echo "<td>" . $row['Tijdstip']."</td>";
		echo "<td>" . $row['Personen']."</td>";
		echo "<td>" . $row['Opmerkingen']."</td>";
		echo "<td>" ."<a href='wijzigen.php?ID=".$row['ID']."'> pas aan</a>". "</td>";




		echo "</tr>";
	}


		?>


</table>
<script src="../js/jQuery.js"></script>
<script src="../js/script.js"></script>
</body>
</html>
