<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>

<?php
session_start();
require_once 'config.php';

	// Als het formulier is verstuurd
	if (isset($_POST['inlog']))
	{
		
		
//		// Beveiling van het gegevens!
//		
		//Lees de gegevens uit
		$Voornaam = $_POST['Voornaam'];
		$Achternaam = $_POST['Achternaam'];
		$Wachtwoord = $_POST['Wachtwoord'];
		
		//Maak de querry
		$opdracht = "SELECT * FROM Gebruikers
		WHERE Voornaam = '$Voornaam' AND Wachtwoord = '$Wachtwoord'";
		//Voer de querry uit en van het resultaat op
		$resultaat = mysqli_query($mysqli, $opdracht);
		//Controleer of het resultaat een rij (user) heeft opgeleverd
		if (mysqli_num_rows($resultaat) > 0)
		{
//			//Haal de user het resultaat 
//			$user = mysqli_fetch_array($resultaat);
//			//Zet de gebruikersnaam en Level in 2 verschillende sessions
//			$_SESSION['Gebruikersnaam'] = $user['Gebruikersnaam'];
//			//$_SESSION['Wachtwoord'] = $ww['Wachtwoord'];
//			// $_SESSION['Level'] = $user['Level'];
//			
			
			
			echo "<p>Hallo Mvr/Dhr $Voornaam, u bent ingelogd.</p></br>";
			echo "<a href=''>Klik hier om naar de home pagina te gaan</a>";
		}
		
				
		// Anders:
		else
		{
			echo "<p> Naam en/of wachtwoord zijn onjuist.</p>";
			echo "<p><a href='inlog.php'> Probeer opnieuw</a></p>";
					
			echo mysqli_error($mysqli);  // tijdelijk
		}	
		
				
				
		
	}
		//Als het formulier niet is verstuurd:
	
		?>
<body>
</body>
</html>
